<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Simligh Math</title>
    <style>
      html {
        background-image: url("assets/background/18.png");
      }
    </style>
    <link rel="stylesheet" href="assets/style.css" />
  </head>
  <body>
    <div class="appcontainer">
      <div style="margin: 195% 0 0 12%">
        <a href="{{ route('faqmenu') }}">
          <img src="assets/icon/20.png" width="40%" style="margin-right: 5%" />
        </a>
        <a href="{{ route('faqmenu') }}">
          <img src="assets/icon/21.png" width="40%" />
        </a>
      </div>
    </div>
  </body>
</html>
