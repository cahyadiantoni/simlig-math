<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Simligh Math</title>
    <style>
      html {
        background-image: url("assets/background/9.png");
      }
    </style>
    <link rel="stylesheet" href="assets/style.css" />
  </head>
  <body>
    <div class="appcontainer">
      <div style="margin: 70% 0 0 33%">
        <a href="{{ route('msubstitusi') }}">
          <img src="assets/icon/17.png" width="60%"/>
        </a>
      </div>
      <div style="margin: 10% 0 0 30%">
        <a href="{{ route('meliminasi') }}">
          <img src="assets/icon/18.png" width="60%"/>
        </a>
      </div>
      <div style="margin: 10% 0 0 28%">
        <a href="{{ route('mcampuran') }}">
          <img src="assets/icon/19.png" width="60%"/>
        </a>
      </div>
      <div style="margin: 30% 0 0 8%">
        <a href="{{ route('kspltv') }}">
          <img src="assets/icon/11.png" width="18%" style="margin-right: 17%" />
        </a>
        <a href="{{ route('materi') }}">
          <img src="assets/icon/10.png" width="18%" style="margin-right: 17%" />
        </a>
        <a href="{{ route('msubstitusi') }}">
          <img src="assets/icon/12.png" width="18%" />
        </a>
      </div>
    </div>
  </body>
</html>
