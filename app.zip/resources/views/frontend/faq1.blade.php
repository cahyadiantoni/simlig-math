<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Simligh Math</title>
    <style>
      html {
        background-image: url("assets/background/20.png");
      }
    </style>
    <link rel="stylesheet" href="assets/style.css" />
  </head>
  <body>
    <div class="appcontainer">
      <div style="margin: 207% 0 0 10%">
        <a href="{{ route('faqmenu') }}">
          <img src="assets/icon/11.png" width="15%" style="margin-right: 21%" />
        </a>
        <a href="{{ route('faqmenu') }}">
          <img src="assets/icon/10.png" width="15%" style="margin-right: 21%" />
        </a>
        <a href="{{ route('faq2') }}">
          <img src="assets/icon/12.png" width="15%" />
        </a>
      </div>
    </div>
  </body>
</html>
