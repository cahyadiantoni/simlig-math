<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Simligh Math</title>
    <style>
      html {
        background-image: url("assets/background/28.png");
      }
    </style>
    <link rel="stylesheet" href="assets/style.css" />
  </head>
  <body>
    <div class="appcontainer">
      <div style="margin: 65% 0 0 17%">
        <a href="{{ route('latihans1') }}">
          <img src="assets/icon/34.png" width="80%" />
        </a>
      </div>
      <div style="margin: 5% 0 0 17%">
        <a href="{{ route('latihane1') }}">
          <img src="assets/icon/35.png" width="80%" />
        </a>
      </div>
      <div style="margin: 5% 0 0 17%">
        <a href="{{ route('latihanc1') }}">
          <img src="assets/icon/36.png" width="80%" />
        </a>
      </div>
      <div style="margin: 55% 0 0 8%">
        <a href="{{ route('evaluasi') }}">
          <img src="assets/icon/11.png" width="18%" style="margin-right: 17%" />
        </a>
        <a href="{{ route('evaluasi') }}">
          <img src="assets/icon/10.png" width="18%" style="margin-right: 17%" />
        </a>
        <a href="{{ route('latihans1') }}">
          <img src="assets/icon/12.png" width="18%" />
        </a>
      </div>
    </div>
  </body>
</html>
