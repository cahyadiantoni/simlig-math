<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Simligh Math</title>
    <style>
      html {
        background-image: url("assets/background/5.png");
      }
    </style>
    <link rel="stylesheet" href="assets/style.css" />
  </head>
  <body>
    <div class="appcontainer">
        <div style="margin: 200% 0 0 40%;">
          <a href="{{ route('home') }}">
            <img src="assets/icon/10.png" width="28%"/>
          </a>
        </div>
      </div>
  </body>
</html>
