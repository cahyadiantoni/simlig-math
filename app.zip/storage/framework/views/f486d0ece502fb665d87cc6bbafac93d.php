<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Simligh Math</title>
    <style>
      html {
        background-image: url("assets/background/17.png");
      }
    </style>
    <link rel="stylesheet" href="assets/style.css" />
  </head>
  <body>
    <div class="appcontainer">
      <div style="margin: 180% 0 0 5%">
        <a href="#">
          <img src="assets/icon/38.png" width="94%"/>
        </a>
      </div>
      <div style="margin: 5% 0 0 8%">
        <a href="<?php echo e(route('csspltv4')); ?>">
          <img src="assets/icon/11.png" width="18%" style="margin-right: 17%" />
        </a>
        <a href="<?php echo e(route('materi')); ?>">
          <img src="assets/icon/10.png" width="18%" style="margin-right: 17%" />
        </a>
        <a href="<?php echo e(route('evaluasispltv')); ?>">
          <img src="assets/icon/12.png" width="18%" />
        </a>
      </div>
    </div>
  </body>
</html>
<?php /**PATH D:\Simlig Math\Laravel\simlig\resources\views/frontend/csspltv5.blade.php ENDPATH**/ ?>