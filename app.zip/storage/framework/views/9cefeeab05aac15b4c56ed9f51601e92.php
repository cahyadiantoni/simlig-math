<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Simligh Math</title>
    <style>
      html {
        background-image: url("assets/background/1.png");
      }
    </style>
    <link rel="stylesheet" href="assets/style.css" />
  </head>
  <body>
    <div class="appcontainer">
      <div style="margin: 100% 0 0 40%;">
        <a href="<?php echo e(route('login')); ?>">
          <img src="assets/icon/1.png" width="35%"/>
        </a>
      </div>
    </div>
  </body>
</html>
<?php /**PATH D:\Simlig Math\Laravel\simlig\resources\views/frontend/index.blade.php ENDPATH**/ ?>