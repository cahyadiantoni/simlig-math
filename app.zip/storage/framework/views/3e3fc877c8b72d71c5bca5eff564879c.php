<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Simligh Math</title>
    <style>
      html {
        background-image: url("assets/background/23.png");
      }
    </style>
    <link rel="stylesheet" href="assets/style.css" />
  </head>
  <body>
    <div class="appcontainer">
      <div style="margin: 207% 0 0 10%">
        <a href="<?php echo e(route('faq3')); ?>">
          <img src="assets/icon/11.png" width="15%" style="margin-right: 21%" />
        </a>
        <a href="<?php echo e(route('faqmenu')); ?>">
          <img src="assets/icon/10.png" width="15%" style="margin-right: 21%" />
        </a>
        <a href="<?php echo e(route('faq5')); ?>">
          <img src="assets/icon/12.png" width="15%" />
        </a>
      </div>
    </div>
  </body>
</html>
<?php /**PATH D:\Simlig Math\Laravel\simlig\resources\views/frontend/faq4.blade.php ENDPATH**/ ?>